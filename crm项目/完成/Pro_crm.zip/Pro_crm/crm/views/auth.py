
import hashlib
from crm import models
from crm.forms import RegForm
from rbac.service.init_permission import init_permission
from django.shortcuts import reverse, redirect, render


def login(request):
    if request.session.get('is_login'):
        request.session.flush()
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        md5 = hashlib.md5()
        md5.update(password.encode('utf-8'))
        obj = models.UserProfile.objects.filter(username=username, password=md5.hexdigest(), is_active=True).first()
        if obj:
            init_permission(request, obj)
            request.session['is_login'] = True
            request.session['user_id'] = obj.pk
            return redirect(reverse('index'))
        else:
            return render(request, 'login.html', {'error': '用户名或密码错误'})
    return render(request, 'login.html')


def register(request):
    form_obj = RegForm()
    if request.method == 'POST':
        form_obj = RegForm(request.POST)
        if form_obj.is_valid():
            form_obj.save()
            return redirect(reverse('login'))
    return render(request, 'reg.html', {'form_obj': form_obj})


def index(request):
    return render(request, 'index.html')
# def add_customer(request):
#     form_obj = Customer_form()
#     if request.method == 'POST':
#         form_obj = Customer_form(request.POST)
#         if form_obj.is_valid():
#             form_obj.save()
#             return redirect(reverse('customer'))
#     return render(request, 'add_customer.html', {'form_obj': form_obj})

